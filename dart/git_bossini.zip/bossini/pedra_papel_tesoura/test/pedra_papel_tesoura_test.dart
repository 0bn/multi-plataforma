import 'package:pedra_papel_tesoura/pedra_papel_tesoura.dart';
import 'package:test/test.dart';

void main() {
  test('calculate', () {
    expect(calculate(), 42);
  });
}
