//importar o módulo para entrada/saída

//importar o módulo para gerar valores aleatórios

//criar um enum que representa as opções (pedra, papel ...)

void jogo(){
  //loop (do/while) do jogo, executa até o  usuário decidir sair

    //exibir o menu
    //capturar a opção do usuário e validar com do/while (só vale de 1 a 4)

    //sortear a opção do computador

    //mapear a opção do usuário, de int para enum

    //mapear a opção do computador, de int para enum

    //exibir as opções de cada um
    //JOGADOR(pedra) vs (tesoura)COMPUTADOR

    //verificar e exibir o resultado (ganho do jogador, ganho do computador ou empate)
}
