switch([a, b]){

}

// void main(){
//   //switch expression
//   var mediaFinal = 10;
//   int op;
//   //1 - Comer
//   //2 - Beber
//   switch(op){
//     case 1: f.ewafwea;
//   }
//   var conceito = switch(mediaFinal){
//     10 || 9 => 'A',
//     8 => 'B',
//     _ => 'R'
//   };
//   var a = print(conceito);
//   print(a);
//   // var a = var b;
//   //statement versus expression
//   // var idade = 18;
//   // // var podeDirigir = idade >= 18 ? 'Sim' : 'Não'; //expression
//   // var podeDirigir = if(idade >= 18) 'Sim' else 'Não';//statement
//   // var lista = ['banana', 'laranja'];
//   // switch(lista){
//   //   case ['banana', 'laranja']:
//   //     print('A');
//   //   case ['laranja', 'banana']:
//   //     print('B');
//   // }

//   // const nota = 10; //fall-through
//   // switch(nota){
//   //   case 10 || 9 || 8:
//   //     print('A');
//   // }
//   // switch(nota){
//   //   case 10:
//   //   case 9:
//   //     print ('A');
//   //   case 8:
//   //     print('B');
//   //   default:
//   //     print('R');
//   // }  
// }

// // void main(){
// //   for (var i = 0; i < 10; i++){

// //   }
// // }

// // void main(){
// //   //var, final e const (inferência de tipo (feito pelo compilador))
// //   //princípio do menor privilégio
// //   //1. Se o valor for conhecido já no momento da declaração
// //   //2. Se o valor for conhecido em tempo de compilação
// //   String nome = "Ana";
// //   var m = nome.toUpperCase();
// //   m = nome.toLowerCase();
// //   // String nome = "Ana";
// //   // final emMaiusculo = nome.toUpperCase();

// //   // final a;
// //   // a = "abc";
// //   // print(a);
// //   // print(a.runtimeType);
// //   // final a = 2;
// //   // a = "abc";
// // }


// // // class Animal{
// // //   public void fazerBarulho(){}
// // // }


// // // class Gato extends Animal{
// // //   @Override
// // //   public void fazerBarulho(){
// // //     sysout('miau');
// // //   }
// // // }

// // // // class Null{

// // // // }
// // // // Null null = new Null();
// // // //inferência de tipos(feita pelo compilador)
// // // //var, final e const
// // // void main(){
// // //   // var m = [['abc', 'd']];
// // //   var a = Null;
// // //   print(a);
// // //   print(a.runtimeType.runtimeType.runtimeType);
// // //   // String nome = 'João';
// // //   // nome = 1;
// // // }

// // // // void main(){
// // // //   int a = 3;
// // // //   print(a.runtimeType);

// // // //   dynamic b = 2;
// // // //   print(b.runtimeType);
// // // //   b = "abc";
// // // //   print(b.runtimeType);
// // // // }

// // // // //estático, feito pelo compilador
// // // // double d = 2;
// // // // d.correr();


// // // // //dinâmico, feito pelo ambiente de execução
// // // // e = 2
// // // // e = "abc"
// // // // e.correr()


// // // // //gradual, engloba tanto o estático quanto o dinâmico
// // // // let a: number = 2
// // // // a.falar()

// // // // //dynamic a = 2
// // // // int a = 2


// // // // // void main(){
// // // // //   int a = 2;
// // // // //   ++a;
// // // // //   print(a);
// // // // //   a++;
// // // // //   print(a);
// // // // //   print(++a);
// // // // //   print(a++);
// // // // //   print(a);
// // // // //   // double dividendo = 6;
// // // // //   // int divisor = 2;
// // // // //   // num quociente = 3 / 2;
// // // // //   // print(quociente.runtimeType);
// // // // //   // double a = 1.2;
// // // // //   // int b = a.round();
// // // // //   // b = a.floor();
// // // // //   // b = a.ceil();
// // // // //   // double d = 1;
// // // // //   // print(d.runtimeType);
// // // // //   // int a = 1;
// // // // //   // double b = a;
// // // // //   //conversões
// // // // //   // de string para int
// // // // //   // String idadeTextual = '25';
// // // // //   // int idade = int.parse(idadeTextual);
// // // // //   // print(idade);

// // // // //   // String pesoTextual = "80.2";
// // // // //   // double peso = double.parse(pesoTextual);
// // // // //   // print(peso);
// // // // //   // print(peso.runtimeType);

// // // // //   // String alturaTextual = "1.2";
// // // // //   // num altura = int.parse(alturaTextual);
// // // // //   // print(altura);
// // // // //   // print(altura.runtimeType);

// // // // //   //multiplicação de strings
// // // // //   // String letra = 'x';
// // // // //   // print(letra * 10);
// // // // //   // //concatenação
// // // // //   // String nome = "Pedro";
// // // // //   // int idade = 22;
// // // // //   // print("Me chamo " + nome);
// // // // //   // print("Tenho " + idade.toString() + " anos");
// // // // //   // //interpolação
// // // // //   // print('Me chamo $nome');
// // // // //   // print("No ano que vem vou ter ${idade + 1} anos");
// // // // //   // String nome = "João";
// // // // //   // print(nome);
// // // // //   // print(nome.runtimeType);
// // // // //   // String teste = 'Use \n para pular uma linha';
// // // // //   // print(teste);

// // // // //   /*
// // // // //     esse é um
// // // // //     comentário
// // // // //     de múltiplas
// // // // //     linhas
// // // // //    */
// // // // //   //print('Hello, World');
// // // // // }